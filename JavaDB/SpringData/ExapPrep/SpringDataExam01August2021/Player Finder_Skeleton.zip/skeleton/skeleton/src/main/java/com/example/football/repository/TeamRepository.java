package com.example.football.repository;

//ToDo:
public interface TeamRepository {
}
