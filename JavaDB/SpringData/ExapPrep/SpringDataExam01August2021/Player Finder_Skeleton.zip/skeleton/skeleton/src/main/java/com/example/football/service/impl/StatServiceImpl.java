package com.example.football.service.impl;

import com.example.football.service.StatService;

//ToDo - Implement all methods
public class StatServiceImpl implements StatService {


    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readStatsFileContent()  {
        return null;
    }

    @Override
    public String importStats() {
        return null;
    }
}
