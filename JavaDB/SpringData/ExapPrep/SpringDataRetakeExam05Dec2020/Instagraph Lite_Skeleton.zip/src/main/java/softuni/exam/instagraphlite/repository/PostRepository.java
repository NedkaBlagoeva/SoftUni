package softuni.exam.instagraphlite.repository;

//ToDo
public interface PostRepository {
}
