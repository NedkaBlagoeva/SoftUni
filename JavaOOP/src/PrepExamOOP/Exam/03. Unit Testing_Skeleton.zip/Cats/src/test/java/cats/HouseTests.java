package cats;

public class HouseTests {

}
